# NFT Landing page project-4

A NFTs Landing page project which shows all downs and ups regarding NFT.

--> This is one of my best UI design I've ever created please have a look on website by opening it into your local device.

This project is created during the milestone exam-1 conducted by the PW Skills FSWD 2.0 course.

## Features

- Responsive design, ensuring compatibility across different devices.
- User-friendly interface with intuitive navigation for easy learning.
- customized scrollbar

## Tech Stack

- HTML
- Tailwind


## Contact

Let's connect! You can reach me via:

- LinkedIn: https://www.linkedin.com/in/madin-bloch/
- Email: Madinkhan0633@gmail.com
---