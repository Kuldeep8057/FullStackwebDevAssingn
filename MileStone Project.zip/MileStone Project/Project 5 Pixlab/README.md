# Pixelab Landing page project-5

A Landing page of a startup company named "Pixelab" which has motive to boost their client's profit by bringing them to digital platform from their offline business and expand their client's business across the globe by using their digital services and expertise.

This project is created during the milestone exam-1 conducted by the PW Skills FSWD 2.0 course.

## Features

- Responsive design, ensuring compatibility across different devices.
- User-friendly interface with intuitive navigation for easy learning.

## Tech Stack

- HTML
- Tailwind


## Contact

Let's connect! You can reach me via:

- LinkedIn: https://www.linkedin.com/in/madin-bloch/
- Email: Madinkhan0633@gmail.com
---