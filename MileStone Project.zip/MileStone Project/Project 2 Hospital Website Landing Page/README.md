# Hosptial Landing page project-2

A Hosptial Landing page which shows about its Hopsital's specialities, about his surgeons, facilities and many more.

This project is created during the milestone exam-1 conducted by the PW Skill's FSWD 2.0 course.

## Features

- User-friendly interface with intuitive navigation for easy learning.

## Tech Stack

- HTML
- CSS

## Contact

Let's connect! You can reach me via:

- LinkedIn: https://www.linkedin.com/in/madin-bloch/
- Email: Madinkhan0633@gmail.com
---