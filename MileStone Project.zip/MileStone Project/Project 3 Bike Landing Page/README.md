# Bike Landing Page project-3


A Bike landing page which tells about it's bike's features, facilities, Quality, Pricing and many more things about his Bike's company / startup.

This project is created during the milestone exam-1 conducted by the PW Skills FSWD 2.0 course.

## Features

- User-friendly interface with intuitive navigation for easy learning.

## Tech Stack

- HTML
- TailwindCss

## Additional websites

- Unicons

## Contact

Let's connect! You can reach me via:

- LinkedIn: https://www.linkedin.com/in/madin-bloch/
- Email: Madinkhan0633@gmail.com
---